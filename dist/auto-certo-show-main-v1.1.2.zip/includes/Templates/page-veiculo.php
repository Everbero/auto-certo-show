<?php
/* Template Name: Página Veículo */

get_header(); ?>

<div id="auto-certo-veiculo"></div>

<?php get_footer(); ?>
